package com.example.botbuddies

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.Button

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var game: BotView? = null
    private var stopBtn: Button? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startForegroundCompat()
        if (game != null) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }

        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val type = LP.TYPE_APPLICATION_OVERLAY

        // Game layer: full screen, transparent, NOT touchable, so taps go to the app underneath.
        val g = BotView(this)
        manager.addView(g, LP(
            LP.MATCH_PARENT, LP.MATCH_PARENT, type,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ))
        game = g

        // Stop button: its own small window, the only touchable part.
        val b = Button(this).apply {
            text = "STOP"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(230, 200, 30, 30))
            setOnClickListener { stopSelf() }
        }
        manager.addView(b, LP(
            LP.WRAP_CONTENT, LP.WRAP_CONTENT, type,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.END; x = 24; y = 160 })
        stopBtn = b
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bots", "Bot Buddies", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "bots")
            .setSmallIcon(android.R.drawable.ic_menu_close_clear_cancel)
            .setContentTitle("Bot Buddies is running")
            .setContentText("Tap Stop to remove the bots")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        runCatching { wm?.removeView(game) }
        runCatching { wm?.removeView(stopBtn) }
        game = null
        stopBtn = null
        super.onDestroy()
    }

    companion object { const val ACTION_STOP = "com.example.botbuddies.STOP" }
}
