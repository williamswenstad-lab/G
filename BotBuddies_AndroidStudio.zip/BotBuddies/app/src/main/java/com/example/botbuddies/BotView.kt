package com.example.botbuddies

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

class BotView(ctx: Context) : View(ctx) {
    private class Bot(var x: Float, var y: Float, var hue: Float)

    private val d = resources.displayMetrics.density
    private val size = 56f * d
    private val maxBots = 25            // safety cap so it never eats memory or battery
    private val bots = ArrayList<Bot>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var vx = 260f * d
    private var vy = 200f * d
    private var last = 0L
    private var spawn = 0f
    private var clock = 0f

    override fun onDraw(c: Canvas) {
        if (bots.isEmpty()) bots.add(Bot(width / 3f, height / 3f, 0f))
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min((now - last) / 1e9f, 0.05f)
        last = now
        step(dt)
        for (i in bots.indices.reversed()) drawBot(c, bots[i], i == 0)
        postInvalidateOnAnimation()
    }

    private fun step(dt: Float) {
        val lead = bots[0]
        val half = size * 0.65f
        lead.x += vx * dt
        lead.y += vy * dt
        if (lead.x < half) { lead.x = half; vx = abs(vx) } else if (lead.x > width - half) { lead.x = width - half; vx = -abs(vx) }
        if (lead.y < half) { lead.y = half; vy = abs(vy) } else if (lead.y > height - half) { lead.y = height - half; vy = -abs(vy) }
        lead.hue = (lead.hue + 70f * dt) % 360f

        clock += dt
        spawn += dt
        if (spawn > 2f) {                       // duplicate every 2 seconds
            spawn = 0f
            if (bots.size >= maxBots) bots.removeAt(1)
            bots.add(Bot(lead.x, lead.y, lead.hue))
        }
        for (i in 1 until bots.size) {          // everyone chases the first bot
            val b = bots[i]
            val a = i * 2.4f + clock * 0.6f
            val r = min((30f + 6f * i) * d, 140f * d)
            val k = 1f - exp(-3f * dt)
            b.x += (lead.x + cos(a) * r - b.x) * k
            b.y += (lead.y + sin(a) * r - b.y) * k
            b.x = b.x.coerceIn(size / 2, width - size / 2)
            b.y = b.y.coerceIn(size / 2, height - size / 2)
            b.hue = (((lead.hue - 14f * i) % 360f) + 360f) % 360f
        }
    }

    private fun drawBot(c: Canvas, b: Bot, leader: Boolean) {
        val u = size * (if (leader) 1.3f else 1f) / 100f
        val ox = b.x - 50f * u
        val oy = b.y - 50f * u
        paint.style = Paint.Style.FILL
        paint.color = Color.HSVToColor(floatArrayOf(b.hue, 0.85f, 1f))
        c.drawArc(ox + 20 * u, oy + 10 * u, ox + 80 * u, oy + 70 * u, 180f, 180f, true, paint)   // head
        c.drawRoundRect(ox + 20 * u, oy + 44 * u, ox + 80 * u, oy + 80 * u, 8 * u, 8 * u, paint) // body
        c.drawRoundRect(ox + 8 * u, oy + 44 * u, ox + 17 * u, oy + 72 * u, 4.5f * u, 4.5f * u, paint)  // arms
        c.drawRoundRect(ox + 83 * u, oy + 44 * u, ox + 92 * u, oy + 72 * u, 4.5f * u, 4.5f * u, paint)
        c.drawRoundRect(ox + 32 * u, oy + 76 * u, ox + 43 * u, oy + 95 * u, 5 * u, 5 * u, paint)       // legs
        c.drawRoundRect(ox + 57 * u, oy + 76 * u, ox + 68 * u, oy + 95 * u, 5 * u, 5 * u, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3 * u
        paint.strokeCap = Paint.Cap.ROUND
        c.drawLine(ox + 32 * u, oy + 17 * u, ox + 26 * u, oy + 6 * u, paint)                           // antennae
        c.drawLine(ox + 68 * u, oy + 17 * u, ox + 74 * u, oy + 6 * u, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        c.drawCircle(ox + 38 * u, oy + 27 * u, 3.5f * u, paint)                                        // eyes
        c.drawCircle(ox + 62 * u, oy + 27 * u, 3.5f * u, paint)
    }
}
